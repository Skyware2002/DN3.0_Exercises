public class Main {
    public static void main(String[] args) {
        Product product1 = new Product(1, "Apple", "Fruit");
        Product product2 = new Product(2, "keyboard", "Electronics");
        Product product3 = new Product(3, "Potato", "Vegetable");

        Product[] linearSearchProducts = {product1, product2, product3};
        
        Product[] binarySearchProducts = {product1, product2, product3};

        //linear search
        Product linearSearchResult = LinearSearch.search(linearSearchProducts, 2);
        if (linearSearchResult != null) {
            System.out.println("Linear Search Result: " + linearSearchResult.getProductName());
        } else {
            System.out.println("Product not found");
        }

        //binary search
        Product binarySearchResult = BinarySearch.search(binarySearchProducts, 2);
        if (binarySearchResult != null) {
            System.out.println("Binary Search Result: " + binarySearchResult.getProductName());
        } else {
            System.out.println("Product not found");
        }
    }
}