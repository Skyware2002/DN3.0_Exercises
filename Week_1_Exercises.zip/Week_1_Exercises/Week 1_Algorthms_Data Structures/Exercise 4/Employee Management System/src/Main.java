public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        ems.addEmployee(new Employee(1, "Rishab", "Software Engineer", 100000.0));
        ems.addEmployee(new Employee(2, "Alisa", "Data Scientist", 120000.0));
        ems.addEmployee(new Employee(3, "Vineet", "Mechanical Engineer", 110000.0));

        ems.traverseEmployees();

        Employee employee = ems.searchEmployee(2);
        if (employee != null) {
            System.out.println("Employee found: " + employee.getName());
        } else {
            System.out.println("Employee not found.");
        }

        ems.deleteEmployee(2);
        ems.traverseEmployees();
    }
}