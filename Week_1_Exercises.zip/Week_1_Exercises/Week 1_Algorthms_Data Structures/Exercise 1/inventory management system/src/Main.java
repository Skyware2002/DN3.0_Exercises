public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        Product product1 = new Product(1, "IPhone 14", 10, 899.99);
        Product product2 = new Product(2, "Samsung Galaxy Fold", 5, 1199.99);
        Product product3 = new Product(3, "Nokia 3320", 20, 51.99);

        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);

        System.out.println("Current Inventory:");
        printInventory(inventory);

        product1.setQuantity(15);
        inventory.updateProduct(product1);

        System.out.println("Updated Inventory:");
        printInventory(inventory);

        inventory.deleteProduct(2);

        System.out.println("Updated Inventory after deletion:");
        printInventory(inventory);
    }

    public static void printInventory(Inventory inventory) {
        for (Product product : inventory.getProducts().values()) {
            System.out.println("Product ID: " + product.getProductId());
            System.out.println("Product Name: " + product.getProductName());
            System.out.println("Quantity: " + product.getQuantity());
            System.out.println("Price: $" + product.getPrice());
            System.out.println();
        }
    }
}