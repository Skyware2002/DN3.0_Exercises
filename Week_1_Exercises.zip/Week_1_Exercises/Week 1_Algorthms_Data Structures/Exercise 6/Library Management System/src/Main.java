public class Main {
    public static void main(String[] args) {
        LibraryManagementSystem lms = new LibraryManagementSystem();

        lms.addBook(new Book(1, "Book 1", "Author 1"));
        lms.addBook(new Book(2, "Book 2", "Author 2"));
        lms.addBook(new Book(3, "Book 3", "Author 3"));

        Book book = lms.linearSearchByTitle("Book 2");
        if (book!= null) {
            System.out.println("Book found using linear search: " + book.getTitle());
        } else {
            System.out.println("Book not found using linear search.");
        }

        book = lms.binarySearchByTitle("Book 2");
        if (book!= null) {
            System.out.println("Book found using binary search: " + book.getTitle());
        } else {
            System.out.println("Book not found using binary search.");
        }
    }
}