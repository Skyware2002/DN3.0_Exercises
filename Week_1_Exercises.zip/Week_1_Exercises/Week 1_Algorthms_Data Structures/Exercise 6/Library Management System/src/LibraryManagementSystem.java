import java.util.ArrayList;
import java.util.Collections;

public class LibraryManagementSystem {
    private ArrayList<Book> bookList;

    public LibraryManagementSystem() {
        this.bookList = new ArrayList<>();
    }

    public void addBook(Book book) {
        bookList.add(book);
    }

    public Book linearSearchByTitle(String title) {
        for (Book book : bookList) {
            if (book.getTitle().equals(title)) {
                return book;
            }
        }
        return null;
    }

    public Book binarySearchByTitle(String title) {
        Collections.sort(bookList, (b1, b2) -> b1.getTitle().compareTo(b2.getTitle()));
        int low = 0;
        int high = bookList.size() - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            if (bookList.get(mid).getTitle().equals(title)) {
                return bookList.get(mid);
            } else if (bookList.get(mid).getTitle().compareTo(title) < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null;
    }
}