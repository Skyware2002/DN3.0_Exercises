public class Main {
    public static void main(String[] args) {
        TaskManagementSystem tms = new TaskManagementSystem();

        tms.addTask(new Task(1, "Task 1", "In Progress"));
        tms.addTask(new Task(2, "Task 2", "Completed"));
        tms.addTask(new Task(3, "Task 3", "Pending"));

        System.out.println("Tasks:");
        tms.traverseTasks();

        Task task = tms.searchTask(2);
        if (task != null) {
            System.out.println("Task found: " + task.getTaskName());
        } else {
            System.out.println("Task not found.");
        }

        tms.deleteTask(2);

        System.out.println("Tasks after deletion:");
        tms.traverseTasks();
    }
}