public class FutureValueCalculator {
    public static double calculateFutureValue(double principal, double annualInterestRate, int years) {
        // Base case: If no years left, return the principal amount
        if (years == 0) {
            return principal;
        }

        // Recursive case: Calculate future value for the next year
        double interestFactor = 1 + annualInterestRate;
        double futureValue = calculateFutureValue(principal, annualInterestRate, years - 1) * interestFactor;

        return futureValue;
    }
}