
public class Main {
    public static void main(String[] args) {
        double principal = 1000.0; // Initial investment / Past Data
        double annualInterestRate = 0.05; // 5% annual interest rate
        int years = 10; // Number of years

        double futureValue = FutureValueCalculator.calculateFutureValue(principal, annualInterestRate, years);
        System.out.println("Future Value after " + years + " years: $" + futureValue);
    }
}