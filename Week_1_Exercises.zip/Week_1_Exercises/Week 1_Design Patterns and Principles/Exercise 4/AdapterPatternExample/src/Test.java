public class Test {
    public static void main(String[] args) {
        // Create PayPal adapter
        PayPalGateway payPalGateway = new PayPalGateway();
        PayPalAdapter payPalAdapter = new PayPalAdapter(payPalGateway);

        // Process payment using PayPal
        payPalAdapter.processPayment("Credit Card", 100.0);

        // Create Stripe adapter
        StripeGateway stripeGateway = new StripeGateway();
        StripeAdapter stripeAdapter = new StripeAdapter(stripeGateway);

        // Process payment using Stripe
        stripeAdapter.processPayment("Debit Card", 50.0);
    }
}