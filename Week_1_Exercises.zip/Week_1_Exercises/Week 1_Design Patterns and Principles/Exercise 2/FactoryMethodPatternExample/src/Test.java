public class Test {
    public static void main(String[] args) {
        // Create a Word document using the Word document factory
        DocumentFactory wordFactory = new WordDocumentFactory();
        Document wordDocument = wordFactory.createDocument();
        System.out.println("Created a " + wordDocument.getType() + " document.");
        wordDocument.display();

        // Create a PDF document using the PDF document factory
        DocumentFactory pdfFactory = new PdfDocumentFactory();
        Document pdfDocument = pdfFactory.createDocument();
        System.out.println("Created a " + pdfDocument.getType() + " document.");
        pdfDocument.display();

        // Create an Excel document using the Excel document factory
        DocumentFactory excelFactory = new ExcelDocumentFactory();
        Document excelDocument = excelFactory.createDocument();
        System.out.println("Created a " + excelDocument.getType() + " document.");
        excelDocument.display();
    }
}
