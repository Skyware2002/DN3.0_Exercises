public class ExcelDocument implements Document {
    @Override
    public String getType() {
        return "Excel";
    }

    @Override
    public void display() {
        System.out.println("Displaying an Excel document.");
    }
}
