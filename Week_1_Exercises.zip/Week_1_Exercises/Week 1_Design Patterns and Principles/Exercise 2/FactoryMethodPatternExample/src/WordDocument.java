public class WordDocument implements Document {
    @Override
    public String getType() {
        return "Word";
    }

    @Override
    public void display() {
        System.out.println("Displaying a Word document.");
    }
}