public interface Document {
    String getType();
    void display();
}