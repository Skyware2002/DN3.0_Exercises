public class PdfDocument implements Document {
    @Override
    public String getType() {
        return "PDF";
    }

    @Override
    public void display() {
        System.out.println("Displaying a PDF document.");
    }
}