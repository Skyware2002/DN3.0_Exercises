public class Test {
    public static void main(String[] args) {
        Computer basicComputer = new Computer.Builder()
                .setCPU("AMD Ryzen")
                .setRAM(12)
                .setStorage("500GB SDD")
                .build();
        System.out.println("Basic Computer: " + basicComputer);

        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel Core i7")
                .setRAM(16)
                .setStorage("1TB SSD")
                .setGraphicsCard(true)
                .build();
        System.out.println("Gaming Computer: " + gamingComputer);

        Computer serverComputer = new Computer.Builder()
                .setCPU("Intel Xeon")
                .setRAM(32)
                .setStorage("2TB SDD")
                .setSSD(true)
                .build();
        System.out.println("Server Computer: " + serverComputer);
    }
}