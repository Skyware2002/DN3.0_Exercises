public class LoggerTest {
    public void testLogger() {
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();

        System.out.println("Logger 1: " + logger1);
        System.out.println("Logger 2: " + logger2);

        logger1.log("Hello, World!");
        logger2.log("This is a test log.");

        System.out.println("Are both instances the same? " + (logger1 == logger2));
    }
}