/**
 * Test class for the Decorator Pattern implementation.
 */
public class Test {
    public static void main(String[] args) {
        // Create email notifier
        Notifier emailNotifier = new EmailNotifier();

        // Send email notification
        emailNotifier.send("Hello, this is an email notification!");

        // Create SMS decorator for email notifier
        Notifier smsDecorator = new SMSNotifierDecorator(emailNotifier);

        // Send SMS notification
        smsDecorator.send("Hello, this is an SMS notification!");

        // Create Slack decorator for SMS decorator
        Notifier slackDecorator = new SlackNotifierDecorator(smsDecorator);

        // Send Slack notification
        slackDecorator.send("Hello, this is a Slack notification!");
    }
}