/**
 * Component interface for notifiers.
 */
public interface Notifier {
    void send(String message);
}