package com.exercise.BookstoreAPI.services;

import com.exercise.BookstoreAPI.entities.Book;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookService {
    private static List<Book> BookList = new ArrayList<>();
    //Sample Books
    static {
        BookList.add(new Book(1,"Hello World","ABC",125,123456789));
        BookList.add(new Book(2,"Good Day","EFG",205,852963741));
        BookList.add(new Book(3,"Global Cause","HIJ",189,159874236));
    }

    public List<Book> getBookList(){
        return BookList;
    }

    public Book addBook(Book book){
        BookList.add(book);
        return book;
    }

    public void deleteBook(int Id){
        BookList=BookList.stream().filter(book -> book.getId()!=Id).collect(Collectors.toList());
    }

    public void updateBook(Book book,int Id){
        BookList= BookList.stream().map(e->{
            if(e.getId()==Id){
                e.setTitle(book.getTitle());
                e.setAuthor(book.getAuthor());
                e.setPrice(book.getPrice());
                e.setIsbn(book.getIsbn());
            }
            return e;
        }).collect(Collectors.toList());

    }

    public Book getBookById(int id){
        Book book=null;
        try{
            book=BookList.stream().filter(e->e.getId()==id).findFirst().get();
        }catch (Exception e){
            e.printStackTrace();
        }
        return book;
    }

    public List<Book> getBookByTitleAndAuthor(String author,String title){
        List<Book> mathchedList= new ArrayList<>();
        mathchedList=BookList.stream().filter(book -> (author==null ||book.getAuthor().equals(author))
                && (title == null || book.getTitle().equals(title)))
                .collect(Collectors.toList());
        return mathchedList;
    }

}
