package com.exercise.BookstoreAPI.exeption_handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.NoSuchElementException;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ResourceNotFoundException.class)
        public ResponseEntity<String> handleNoSuchElementException(ResourceNotFoundException elementException){
            return new ResponseEntity<String>("No Data Found in DB", HttpStatus.NOT_FOUND);
        }

    @ExceptionHandler(EmptyInputException.class)
    public ResponseEntity<String> handleEmptyInputException(EmptyInputException emptyInputException){
        return new ResponseEntity<String>("No Input Provided", HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
