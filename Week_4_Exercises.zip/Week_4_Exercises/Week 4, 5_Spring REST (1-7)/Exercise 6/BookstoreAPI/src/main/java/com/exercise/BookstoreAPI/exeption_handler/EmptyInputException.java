package com.exercise.BookstoreAPI.exeption_handler;

import org.springframework.stereotype.Component;

@Component
public class EmptyInputException extends RuntimeException{

    public EmptyInputException(){
    }

    public EmptyInputException(String message){
        super(message);
    }

}
