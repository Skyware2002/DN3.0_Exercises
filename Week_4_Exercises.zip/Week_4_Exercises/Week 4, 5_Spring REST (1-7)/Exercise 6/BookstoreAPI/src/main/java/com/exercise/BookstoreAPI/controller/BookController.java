package com.exercise.BookstoreAPI.controller;

import com.exercise.BookstoreAPI.entities.Book;
import com.exercise.BookstoreAPI.exeption_handler.EmptyInputException;
import com.exercise.BookstoreAPI.exeption_handler.ResourceNotFoundException;
import com.exercise.BookstoreAPI.services.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/books/list")
    public ResponseEntity<List<Book>> getBooks() {
        List<Book> bookList=bookService.getBookList();
        if(bookList.size()<=0){
            throw new ResourceNotFoundException();
        }
        return ResponseEntity.of(Optional.of(bookList));
    }

    @PostMapping("/books/add")
    public  ResponseEntity<Book> addBook(@RequestBody Book book) {
        if((book.getTitle()==null ||book.getTitle().isEmpty()) || book.getAuthor()==null ||(book.getAuthor().isEmpty()) || (book.getPrice()<=0) || (book.getIsbn() == 0)){
            throw new EmptyInputException();
        }else {
            try {
                Book book1= new Book();
                book1= this.bookService.addBook(book);
                return ResponseEntity.status(HttpStatus.CREATED).build();
            } catch (Exception e){
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }
    }

    @DeleteMapping("books/{Id}")
    public ResponseEntity<Void> deleteBook(@PathVariable("Id") int Id){
        Book book = bookService.getBookById(Id);
        if(book==null){
            throw new ResourceNotFoundException("No Book Found");
        }
        else{
            try{
                this.bookService.deleteBook(Id);
                return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
            } catch (Exception e){
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }
    }

    @PutMapping("/books/{Id}")
    public ResponseEntity<Book> updateBook(@RequestBody Book book,@PathVariable("Id") int Id){
        Book NUbook = bookService.getBookById(Id);
        if(NUbook==null){
            throw new ResourceNotFoundException("No Book Found");
        }
        else{
            try {
                this.bookService.updateBook(book,Id);
                return ResponseEntity.ok().body(book);
            }catch (Exception e){
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        }
    }

    @GetMapping("/books/{id}")
    public ResponseEntity<Book> getSingleBook(@PathVariable("id") int id) {
        Book book = bookService.getBookById(id);
        if(book==null){
            throw new ResourceNotFoundException("No data exist");
        }
        return ResponseEntity.of(Optional.of(book));
    }


    @GetMapping("/books")
    public List<Book> getBooksByTitleAndAuthor(@RequestParam(required = false) String title, @RequestParam(required = false) String author) {
        if(this.bookService.getBookByTitleAndAuthor(author,title).isEmpty()){
            throw new ResourceNotFoundException("No data exist");
        }
        else {
            return this.bookService.getBookByTitleAndAuthor(author, title);
        }
    }

}
