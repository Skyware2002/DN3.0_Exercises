package com.exercise.BookstoreAPI.controller;

import com.exercise.BookstoreAPI.entities.Book;
import com.exercise.BookstoreAPI.services.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/books/list")
    public List<Book> getBooks() {
        return this.bookService.getBookList();
    }

    @PostMapping("/books/add")
    public  Book addBook(@RequestBody Book book) {
        return this.bookService.addBook(book);
    }

    @DeleteMapping("books/{Id}")
    public void deleteBook(@PathVariable("Id") int Id){
        this.bookService.deleteBook(Id);
    }

    @PutMapping("/books/{Id}")
    public Book updateBook(@RequestBody Book book,@PathVariable("Id") int Id){
        this.bookService.updateBook(book,Id);
        return book;
    }

    @GetMapping("/books/{id}")
    public Book getSingleBook(@PathVariable("id") int id) {
        return bookService.getBookById(id);
    }

    @GetMapping("/books")
    public List<Book> getBooksByTitleAndAuthor(@RequestParam String title, @RequestParam String author) {
        return this.bookService.getBookByTitleAndAuthor(author,title);
    }
    //localhost:8080/books?author=ABC&title=Hello World

}
