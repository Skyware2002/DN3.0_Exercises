package com.exercise.BookstoreAPI.services;

import com.exercise.BookstoreAPI.entities.Customer;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CustomerService {
    private static List<Customer> CustomerList = new ArrayList<>();

    static {
        CustomerList.add(new Customer("Rishab",125478963,"abc@email.com"));
        CustomerList.add(new Customer("Mohit",266934571,"ugd@email.com"));
        CustomerList.add(new Customer("Keshab",794643325,"vesc@email.com"));
    }

    public Customer addCustomer(Customer customer){
        CustomerList.add(customer);
        return customer;
    }

    public List<Customer> getCustomerList(){
        return CustomerList;
    }


}
