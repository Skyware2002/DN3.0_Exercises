package com.exercise.BookstoreAPI.controller;

import com.exercise.BookstoreAPI.entities.Customer;
import com.exercise.BookstoreAPI.services.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    @CrossOrigin
    @PostMapping("/customers")
    public Customer createCustomer(@RequestBody Customer customer) {
        return this.customerService.addCustomer(customer);
    }

    @GetMapping("/customers/list")
    public List<Customer> getCustomers() {
        return this.customerService.getCustomerList();
    }

}
