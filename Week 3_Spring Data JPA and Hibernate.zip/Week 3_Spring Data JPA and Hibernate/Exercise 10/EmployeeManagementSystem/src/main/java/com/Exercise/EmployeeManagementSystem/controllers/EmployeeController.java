package com.Exercise.EmployeeManagementSystem.controllers;

import com.Exercise.EmployeeManagementSystem.entities.Employee;
import com.Exercise.EmployeeManagementSystem.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @PostMapping("/add")
    public Employee createEmployee(@RequestBody Employee employee){
        return employeeRepository.save(employee);
    }

    @GetMapping("/")
    public List<Employee> getAllEmployees(){
        return employeeRepository.findAll();
    }

    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable int id) {
        return employeeRepository.findById(id).get();
    }

    @PutMapping("/edit/{id}")
    public Employee updateEmployee(@PathVariable int id, @RequestBody Employee employeeDet) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            Employee employee = optionalEmployee.get();
            employee.setName(employeeDet.getName());
            employee.setEmail(employeeDet.getEmail());
            employee.setDepartment(employeeDet.getDepartment());
            return employeeRepository.save(employee);
        } else {
            return null;
        }

    }

    @DeleteMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable int id) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            employeeRepository.delete(optionalEmployee.get());
            return "Deleted successfully";
        } else {
            return "Not Deleted ";
        }
    }


    //This should delete the employees in batches using Hibernate's batching feature.
    @DeleteMapping("/delete/batch")
    public String deleteEmployeesInBatch(@RequestBody List<Employee> employees) {
        employeeRepository.deleteEmployeesInBatch(employees);
        return "Employees deleted successfully";
    }



}
