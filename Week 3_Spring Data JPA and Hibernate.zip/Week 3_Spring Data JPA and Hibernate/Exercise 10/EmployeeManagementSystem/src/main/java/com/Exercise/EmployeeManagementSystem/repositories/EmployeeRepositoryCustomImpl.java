package com.Exercise.EmployeeManagementSystem.repositories;

import com.Exercise.EmployeeManagementSystem.entities.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmployeeRepositoryCustomImpl implements EmployeeRepositoryCustom {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void deleteEmployeesInBatch(List<Employee> employees) {
        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();

        int batchSize = 10;
        int count = 0;

        for (Employee employee : employees) {
            session.delete(employee);
            count++;

            if (count % batchSize == 0) {
                session.flush();
                session.clear();
            }
        }

        session.getTransaction().commit();
    }
}