package com.Exercise.EmployeeManagementSystem.repositories;

import com.Exercise.EmployeeManagementSystem.entities.Employee;

import java.util.List;
public interface EmployeeRepositoryCustom {
    void deleteEmployeesInBatch(List<Employee> employees);
}