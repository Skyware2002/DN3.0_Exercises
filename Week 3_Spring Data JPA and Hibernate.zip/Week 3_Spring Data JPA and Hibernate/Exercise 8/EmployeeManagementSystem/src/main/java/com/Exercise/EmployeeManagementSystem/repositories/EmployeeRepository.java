package com.Exercise.EmployeeManagementSystem.repositories;

import com.Exercise.EmployeeManagementSystem.entities.Department;
import com.Exercise.EmployeeManagementSystem.entities.Employee;
import com.Exercise.EmployeeManagementSystem.projection.EmployeeValueProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
    List<Employee> findByName(String name);
    List<Employee> findByDepartment(Department department);

    @Query("select u FROM Employee u")
    public List<Employee> getAllEmployee();

    @Query(value = "select * from employees",nativeQuery = true)
    public List<Employee> getEmployees();

    @Query(value = "select email from employees where employees.name=:e",nativeQuery = true)
    public String getEmailByName(@Param("e") String name);

    @Query(name = "Employee.findNameByEmail")
    List<Employee> findNameByDepartmentId(@Param("id") int id);

    //For Exercise 6
    Page<Employee> findByDepartment_Name(String departmentName, Pageable pageable);

    List<EmployeeValueProjection> findAllProjectedBy();

}
