package com.Exercise.EmployeeManagementSystem.projection;
import org.springframework.beans.factory.annotation.Value;
public interface EmployeeValueProjection {

    @Value("#{target.name + ' ' + target.email}")
    String getName();

    String getEmail();

}

